gps-speed\gps.o: ..\hard\gps\gps.c
gps-speed\gps.o: ..\hard\gps\gps.h
gps-speed\gps.o: D:\procedure\KEIL\ARM\ARMCC\Bin\..\include\stdio.h
gps-speed\gps.o: D:\procedure\KEIL\ARM\ARMCC\Bin\..\include\string.h
gps-speed\gps.o: D:\procedure\KEIL\ARM\ARMCC\Bin\..\include\stdlib.h
